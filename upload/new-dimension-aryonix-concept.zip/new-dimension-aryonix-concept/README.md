# New Dimension × ARYONIX — Website Concept

An **unofficial, cinematic website redesign concept** for **New Dimension**, an
interior design studio in Nagpur, prepared by **ARYONIX** as a
prospective-client demonstration.

> **This is a design demo — not the live website of New Dimension, and not
> affiliated with or endorsed by the firm.** The firm's real website remains at
> [newdimensionngp.com](https://www.newdimensionngp.com) and was not modified
> in any way.

---

## Quick start (VS Code)

**Prerequisites:** [Node.js 20.9+](https://nodejs.org) (LTS recommended) and
[VS Code](https://code.visualstudio.com). On first open, VS Code may suggest the
ESLint + Tailwind CSS IntelliSense extensions (recommended — accept the prompt).

```bash
# 1. Open the project folder in VS Code (File → Open Folder…)
# 2. Open VS Code's integrated terminal (Terminal → New Terminal, Ctrl+`)

# 3. Install dependencies
npm install

# 4. Start the dev server
npm run dev
```

Then open **http://localhost:3000** in your browser.
(If you prefer Bun or pnpm: `bun install && bun run dev` or
`pnpm install && pnpm dev` work identically.)

Other scripts:

| Command           | What it does                     |
| ----------------- | -------------------------------- |
| `npm run dev`     | Dev server at http://localhost:3000 |
| `npm run build`   | Production build                 |
| `npm run start`   | Serve the production build       |
| `npm run lint`    | ESLint check                     |

No database, environment variables, or external services are required — the
site is fully static. The enquiry journey hands off to the studio's published
WhatsApp / email channels at runtime.

> Fonts (Cormorant Garamond + Jost) are fetched from Google Fonts by
> `next/font` on first run — an internet connection is needed the first time
> you start the dev server.

---

## What was verified (and how)

All business facts used on this page were **independently verified** by
fetching and reading the firm's live website at build time
(`newdimensionngp.com`, including `/about-us`, the services listing
`/all-interiordesigner/1`, six `/interiordesigner/*` service pages, and the two
partner bio-sheet pages, rendered in a headless browser):

| Verified on the live site            | Used in this concept                       |
| ------------------------------------ | ------------------------------------------ |
| Firm name, Nagpur location, Boost 360 platform | Header, footer, meta, JSON-LD    |
| Partners: Seema Agrawal & Trupti Agrawal; firm "came into existence in 2007" | Practice facts row, Studio section |
| Published phone **+91 98224 74365**, email **newdimension.ngp@gmail.com**, address **Plot No. 1703, CMPDI Road, Old Jaripatka, Nagpur 440014**, geo coords | Enquiry channels, footer, JSON-LD, WhatsApp/email handoff |
| 14 listed service lines (exact names) | Services section (same order), enquiry select |
| Six service descriptions             | Accordion (adapted, attributed in UI)      |
| Two client testimonials              | Voices section (verbatim, attributed)      |
| Partner bio sheets (education, IIID roles, awards, art practice) | Studio cards (summarised, attributed) |
| Regions: Maharashtra, Madhya Pradesh, Chhattisgarh | Hero, studio, footer          |

**Nothing was invented** — no projects, clients, awards, prices or credentials
beyond the above.

## Honesty guards built into the UI

- Persistent top ribbon: *"ARYONIX concept — design demo, not the live New
  Dimension website"* with a link to the real site.
- Every photograph is labelled **Placeholder**; the gallery carries a
  full disclaimer card and per-image captions ("Placeholder · Unsplash —
  speaks to *service*").
- Testimonials are captioned *"reproduced verbatim as published on
  newdimensionngp.com"*.
- Partner credentials are captioned *"summarised from the bio sheets published
  by the firm on its own website"*.
- The enquiry form **never fakes a submission**: it composes a message (shown
  live in a preview panel) and hands it to the studio's verified WhatsApp or
  email. Nothing is stored or auto-sent. The demo has no backend state.
- `robots: noindex` so the concept stays out of search engines.

## Imagery & licensing

All photography is **placeholder imagery via [Unsplash](https://unsplash.com)**
(Unsplash License — free for commercial and noncommercial use). Files live in
`public/images/` and are **not** represented as New Dimension's work.
Source photo IDs are recorded per gallery item in `src/lib/business.ts`
(`unsplashId`). In production the firm's own photography would replace these.

## Architecture

```
src/
├── app/
│   ├── layout.tsx          # Fonts (Cormorant Garamond + Jost), metadata, JSON-LD, toaster
│   ├── page.tsx            # Section assembly, skip-link, sticky-footer shell
│   └── globals.css         # Ivory/charcoal design tokens, editorial utilities, grain
├── components/site/
│   ├── demo-ribbon.tsx     # Persistent demo labelling
│   ├── site-nav.tsx        # Scroll-aware nav + full-screen mobile overlay
│   ├── hero.tsx            # 100svh cinematic hero (Ken Burns settle + parallax)
│   ├── practice.tsx        # Statement, marquee, parallax image, verified facts
│   ├── services.tsx        # Accordion — 14 published services, 6 with text
│   ├── portfolio.tsx       # Asymmetric gallery, filters, lightbox (Radix Dialog)
│   ├── studio.tsx          # Partner cards + verified credentials, address
│   ├── voices.tsx          # Verified testimonials
│   ├── enquiry.tsx         # Compose-and-handoff enquiry journey (wa.me / mailto)
│   ├── footer.tsx          # Wordmark, verified contact, full disclaimer
│   └── reveal.tsx          # Shared motion primitives (reduced-motion aware)
└── lib/business.ts         # SINGLE SOURCE OF TRUTH — verified data + image credits
```

**Stack:** Next.js 16 (App Router) · TypeScript · Tailwind CSS 4 ·
shadcn/ui · framer-motion · next/font · Sonner.

**Design system:** warm ivory (`#F2EDE3`) / charcoal (`#171310`) with a
restrained bronze (`#A08148`) accent; Cormorant Garamond display serif +
Jost sans with letter-spaced uppercase eyebrows; hairline rules; film-grain
overlay; staggered line-mask reveals; asymmetric 12-column gallery rhythm.

**Accessibility:** semantic landmarks, skip link, ARIA on tabs/accordion/menu,
keyboard-operable overlay + lightbox (Escape closes), `role="alert"` form
errors, `aria-live` counters, alt text on every image,
`prefers-reduced-motion` fully respected.

## Tested

Verified in a headless browser at 1440×900 and 390×844:

- Hero, marquee, accordion, asymmetric gallery, studio, voices, enquiry, footer all render cleanly (no console errors).
- Gallery filter tabs (All / Residential / Workspace / Hospitality / Retail) animate correctly.
- Lightbox opens, navigates (prev/next), closes via Escape.
- Enquiry form: live message preview, validation errors, **WhatsApp handoff confirmed end-to-end** — the composed message reaches `wa.me/919822474365` with the studio's verified number.
- Mobile: overlay menu navigation, stacked layouts, sticky footer pushed naturally (no gaps/overlap).
