import type { Metadata } from "next";
import { Cormorant_Garamond, Jost } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { BUSINESS } from "@/lib/business";

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  style: ["normal", "italic"],
  display: "swap",
});

const jost = Jost({
  variable: "--font-jost",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "New Dimension — Interior Design, Nagpur · Concept by ARYONIX",
  description:
    "An unofficial cinematic website concept for New Dimension, a partner-led interior design studio in Nagpur. Designed by ARYONIX as a prospective-client demonstration — not the firm's live website.",
  keywords: [
    "New Dimension",
    "interior design Nagpur",
    "ARYONIX",
    "website concept",
    "vastu interior design",
  ],
  authors: [{ name: "ARYONIX" }],
  icons: { icon: "/nd-monogram.svg" },
  robots: { index: false, follow: false },
  openGraph: {
    title: "New Dimension — Interior Design, Nagpur · Concept by ARYONIX",
    description:
      "Unofficial design concept by ARYONIX for New Dimension, interior design studio, Nagpur. Demo only — not the firm's live website.",
    type: "website",
  },
};

/** Structured data using only contact facts verified on newdimensionngp.com */
const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: BUSINESS.name,
  description:
    "Interior design studio in Nagpur working across residential, commercial, hospitality and retail spaces, with a vastu-rooted practice. Details as published on the firm's website.",
  telephone: BUSINESS.phoneTel,
  email: BUSINESS.email,
  url: BUSINESS.liveSite,
  address: {
    "@type": "PostalAddress",
    streetAddress: "Plot No. 1703, CMPDI Road, Old Jaripatka",
    addressLocality: "Nagpur",
    postalCode: "440014",
    addressCountry: "IN",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: BUSINESS.geo.lat,
    longitude: BUSINESS.geo.lng,
  },
  areaServed: BUSINESS.regions,
  foundingDate: String(BUSINESS.establishedYear),
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={`${cormorant.variable} ${jost.variable}`}>
      <body className="antialiased bg-ivory text-ink grain">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessJsonLd) }}
        />
        {children}
        <Toaster position="bottom-right" />
      </body>
    </html>
  );
}
