import { DemoRibbon } from "@/components/site/demo-ribbon";
import { SiteNav } from "@/components/site/site-nav";
import { Hero } from "@/components/site/hero";
import { Practice } from "@/components/site/practice";
import { Services } from "@/components/site/services";
import { Portfolio } from "@/components/site/portfolio";
import { Studio } from "@/components/site/studio";
import { Voices } from "@/components/site/voices";
import { Enquiry } from "@/components/site/enquiry";
import { SiteFooter } from "@/components/site/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-ivory text-ink flex flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-10 focus:z-[100] focus:bg-ink focus:px-4 focus:py-2 focus:text-ivory focus:eyebrow"
      >
        Skip to content
      </a>

      <DemoRibbon />
      <SiteNav />

      <main id="main" className="flex-1">
        <Hero />
        <Practice />
        <Services />
        <Portfolio />
        <Studio />
        <Voices />
        <Enquiry />
      </main>

      <SiteFooter />
    </div>
  );
}
