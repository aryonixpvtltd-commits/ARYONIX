/**
 * ─────────────────────────────────────────────────────────────────────────────
 * SINGLE SOURCE OF TRUTH — VERIFIED BUSINESS DATA
 * ─────────────────────────────────────────────────────────────────────────────
 * Every fact below was independently verified on the firm's live website
 * (https://www.newdimensionngp.com — a Boost 360 / NowFloats template site)
 * at the time of building this concept. Nothing here is invented.
 *
 * Claims that the firm publishes about itself are kept close to the source
 * wording and are attributed in the UI ("as published by the firm").
 * Imagery used across the site is licensed placeholder photography
 * (Unsplash) and is never presented as New Dimension's own work.
 * ─────────────────────────────────────────────────────────────────────────────
 */

export const BUSINESS = {
  name: "New Dimension",
  nameStyled: "NEW DIMENSION",
  taglineSource: "Interior design studio — Nagpur",
  liveSite: "https://www.newdimensionngp.com",
  establishedYear: 2007,
  phoneDisplay: "+91 98224 74365",
  phoneTel: "+919822474365",
  whatsapp: "919822474365",
  email: "newdimension.ngp@gmail.com",
  addressLine1: "Plot No. 1703, CMPDI Road",
  addressLine2: "Old Jaripatka, Nagpur 440014",
  addressFull: "Plot No. 1703, CMPDI Road, Old Jaripatka, Nagpur 440014",
  geo: { lat: 21.1793336, lng: 79.0852704 },
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=21.1793336,79.0852704",
  regions: ["Maharashtra", "Madhya Pradesh", "Chhattisgarh"],
} as const;

/** The firm's own positioning, quoted / adapted from its About page. */
export const POSITIONING = {
  eyebrow: "The practice",
  statement: ["Edgy, yet attainable.", "Current, yet timeless."],
  statementNote:
    "The firm's own words describe a “balance of edgy, yet attainable design, producing both current and timeless interiors”.",
  body: `New Dimension is a partner-led interior design studio in Nagpur. Its practice is rooted in vastu and carried by an artist's hand — the founders describe pairing modern and traditional sensibilities “with a bit of unexpected whimsy”, with space-saving simplicity at the root of impactful design.`,
  bodyNote:
    "Description adapted from the firm's published About page (newdimensionngp.com).",
} as const;

export const FACTS = [
  { value: "2007", label: "Year the firm was established", note: "As stated in both partners' published bio sheets" },
  { value: "14", label: "Listed service lines", note: "Counted on the firm's services page" },
  { value: "3", label: "States served", note: "Maharashtra, Madhya Pradesh, Chhattisgarh" },
  { value: "2", label: "Partner designers", note: "Seema Agrawal & Trupti Agrawal" },
] as const;

/**
 * All 14 services exactly as listed on the firm's services page
 * ("InteriorDesigner (14)"), in the order the firm lists them.
 * Six carry descriptions adapted from the firm's own service pages;
 * the remainder are listed without published descriptions.
 */
export type Service = {
  name: string;
  description?: string;
  hasDetail: boolean;
};

export const SERVICES: Service[] = [
  {
    name: "Residential design",
    hasDetail: true,
    description:
      "Turning a house into a home — the firm describes residential work as merging artistic creativity, functionality and well-being, so a space not only looks beautiful but feels comfortable and personal.",
  },
  {
    name: "Office space design",
    hasDetail: true,
    description:
      "Work environments that promote genuine collaboration and a healthy company culture — seating and planning that bring teams into organic proximity.",
  },
  {
    name: "Restaurant design",
    hasDetail: true,
    description:
      "Bringing a restaurant's brand and personality to life — focused, functional, inviting and consistent, with room allowed for expansion, renovation and longevity.",
  },
  {
    name: "Commercial interior design",
    hasDetail: true,
    description:
      "Planning public and corporate spaces — government buildings, private businesses, offices, schools, banks and retail establishments.",
  },
  {
    name: "Hospitality design",
    hasDetail: true,
    description:
      "Interiors for service industries — restaurants, bars, clubs, cafés, pop-up dining, spas, lounges and more.",
  },
  {
    name: "Apartment house design",
    hasDetail: false,
  },
  { name: "Farmhouse design", hasDetail: false },
  { name: "Resort design", hasDetail: false },
  {
    name: "Detailed drawings",
    hasDetail: false,
  },
  { name: "Healthcare interior design", hasDetail: false },
  { name: "Interior spaces", hasDetail: false },
  { name: "Project management", hasDetail: false },
  { name: "Retail and showroom design", hasDetail: false },
  {
    name: "Vastu consultancy",
    hasDetail: true,
    description:
      "Vastu consultation for home interiors, plots, apartments and bungalows — the foundation on which the firm says its practice is built.",
  },
];

/** Two testimonials, quoted verbatim from the firm's live testimonials page. */
export const TESTIMONIALS = [
  {
    quote:
      "They are very professional & cost effective too. I am happy & satisfied with the services.",
    author: "Karim K Dhamani",
  },
  {
    quote:
      "Very friendly, cooperative and understanding. Just tell them your wish and they turn your ideas into reality.",
    author: "Vishal Ghate",
  },
] as const;

export const TESTIMONIALS_NOTE =
  "Client testimonials reproduced verbatim as published on newdimensionngp.com.";

/** Partner profiles — credential highlights as published on the firm's bio sheets. */
export const PARTNERS = [
  {
    name: "Seema Agrawal",
    role: "Co-founder & Design Partner",
    initials: "SA",
    credentials: [
      "B.Tech in Interior Designing — LAD College, Nagpur (1996)",
      "Post-Graduation Diploma in Vedic Vastu (PGDVV)",
      "Guest faculty and jury member — LAD College & Cadence Institute, Nagpur",
      "IIID Nagpur Chapter — Secretary 2019–21, Treasurer 2021–23, Chairperson elect 2023–25",
      "1st Runner-up, I Design Excellence Award 2024; a project received a Hall of Fame award at the same event",
    ],
  },
  {
    name: "Trupti Agrawal",
    role: "Co-founder & Art Partner",
    initials: "TA",
    credentials: [
      "Graduate — VMV College, Nagpur; Interior Designing — LAD College (2000)",
      "Post-Graduation Diploma in Vedic Vastu (PGDVV)",
      "Practising artist — Tanjore, marquetry, liquid-gold painting, ceramic and mixed media",
      "Kala Ratna Award 2018; Emerging Artist Award, Art India Chitrakala 2023",
      "1st Runner-up, I Design Excellence Award 2024",
    ],
  },
] as const;

export const PARTNERS_NOTE =
  "Partner details summarised from the bio sheets published by the firm on its own website.";

/**
 * Gallery — licensed placeholder photography (Unsplash License).
 * These images DO NOT depict New Dimension projects, clients or premises.
 */
export type GalleryCategory =
  | "Residential"
  | "Workspace"
  | "Hospitality"
  | "Retail";

export type GalleryItem = {
  src: string;
  alt: string;
  title: string;
  category: GalleryCategory;
  /** Suggested New Dimension service line this visual speaks to. */
  serviceHint: string;
  unsplashId: string;
  tall?: boolean;
};

export const GALLERY: GalleryItem[] = [
  {
    src: "/images/living-room.jpg",
    alt: "Placeholder visual — sunlit ivory living room with cognac leather sofa, cream armchairs and a gallery wall",
    title: "Living room",
    category: "Residential",
    serviceHint: "Residential design",
    unsplashId: "photo-1600210492486-724fe5c67fb0",
    tall: true,
  },
  {
    src: "/images/office-lounge.jpg",
    alt: "Placeholder visual — industrial workspace with long shared tables and steel-framed glazing",
    title: "Workspace",
    category: "Workspace",
    serviceHint: "Office space design",
    unsplashId: "photo-1497366811353-6870744d04b2",
  },
  {
    src: "/images/restaurant.jpg",
    alt: "Placeholder visual — fine-dining table laid with plates and glassware in warm light",
    title: "Fine dining",
    category: "Hospitality",
    serviceHint: "Restaurant design",
    unsplashId: "photo-1414235077428-338989a2e8c0",
  },
  {
    src: "/images/apartment.jpg",
    alt: "Placeholder visual — deep green living room with cognac sofa and curated art wall",
    title: "Apartment interior",
    category: "Residential",
    serviceHint: "Apartment house design",
    unsplashId: "photo-1615873968403-89e068629265",
  },
  {
    src: "/images/hotel.jpg",
    alt: "Placeholder visual — resort suite with timber bed, stone walls and glass partition",
    title: "Suite",
    category: "Hospitality",
    serviceHint: "Resort design",
    unsplashId: "photo-1578683010236-d716f9a3f461",
    tall: true,
  },
  {
    src: "/images/retail.jpg",
    alt: "Placeholder visual — menswear store with hanging garments under pendant lights",
    title: "Showroom",
    category: "Retail",
    serviceHint: "Retail and showroom design",
    unsplashId: "photo-1441986300917-64674bd600d8",
  },
  {
    src: "/images/kitchen.jpg",
    alt: "Placeholder visual — kitchen with white cabinetry, marble worktop and timber island",
    title: "Kitchen",
    category: "Residential",
    serviceHint: "Residential design",
    unsplashId: "photo-1556912167-f556f1f39fdf",
  },
  {
    src: "/images/cafe.jpg",
    alt: "Placeholder visual — industrial café with timber tables and pendant lighting",
    title: "Café",
    category: "Hospitality",
    serviceHint: "Hospitality design",
    unsplashId: "photo-1555396273-367ea4eb4db5",
  },
  {
    src: "/images/office-desk.jpg",
    alt: "Placeholder visual — bright collaborative office lounge with soft seating",
    title: "Office lounge",
    category: "Workspace",
    serviceHint: "Office space design",
    unsplashId: "photo-1524758631624-e2822e304c36",
    tall: true,
  },
  {
    src: "/images/dining-green.jpg",
    alt: "Placeholder visual — dining room with emerald velvet chairs and brass chandelier",
    title: "Dining room",
    category: "Residential",
    serviceHint: "Residential design",
    unsplashId: "photo-1617806118233-18e1de247200",
  },
  {
    src: "/images/boutique.jpg",
    alt: "Placeholder visual — boutique interior with garment racks in warm tones",
    title: "Boutique",
    category: "Retail",
    serviceHint: "Retail and showroom design",
    unsplashId: "photo-1567401893414-76b7b1e5a7a5",
  },
  {
    src: "/images/armchair.jpg",
    alt: "Placeholder visual — ochre armchair beneath a brass reading lamp and charcoal cabinetry",
    title: "Reading corner",
    category: "Residential",
    serviceHint: "Interior spaces",
    unsplashId: "photo-1586023492125-27b2c045efd7",
  },
] as const;

export const GALLERY_NOTE =
  "Placeholder imagery — licensed photography via Unsplash, shown purely to illustrate layout and art direction. None of it depicts New Dimension's projects, clients or premises.";

export const GALLERY_FILTERS = [
  "All",
  "Residential",
  "Workspace",
  "Hospitality",
  "Retail",
] as const;

export const CREDIT = {
  concept: "ARYONIX",
  conceptLine:
    "Unofficial website concept prepared by ARYONIX as a prospective-client demonstration.",
  disclaimer:
    "This is a design demonstration only. It is not the live website of New Dimension, is not affiliated with or endorsed by the firm, and makes no commercial claims on its behalf. Facts shown were verified on the firm's live site (newdimensionngp.com) at the time this concept was built.",
  photography:
    "All photography is placeholder imagery via Unsplash, used under the Unsplash License. It does not represent New Dimension's work.",
} as const;

/** Verified phone used for the WhatsApp handoff in the enquiry journey. */
export function whatsappUrl(message: string): string {
  return `https://wa.me/${BUSINESS.whatsapp}?text=${encodeURIComponent(message)}`;
}

export function mailtoUrl(subject: string, body: string): string {
  return `mailto:${BUSINESS.email}?subject=${encodeURIComponent(
    subject
  )}&body=${encodeURIComponent(body)}`;
}
