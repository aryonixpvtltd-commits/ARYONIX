"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { EASE } from "./reveal";

const LINKS = [
  { href: "#practice", label: "Practice", index: "01" },
  { href: "#services", label: "Services", index: "02" },
  { href: "#work", label: "Work", index: "03" },
  { href: "#studio", label: "Studio", index: "04" },
  { href: "#enquire", label: "Enquire", index: "05" },
];

export function SiteNav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const close = useCallback(() => setOpen(false), []);

  // Lock body scroll while the overlay menu is open
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  // Escape closes the overlay
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, close]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-7 z-[70] transition-all duration-500 ${
          scrolled
            ? "bg-ivory/85 backdrop-blur-md border-b border-line shadow-[0_8px_30px_-18px_rgb(23_19_16/0.25)]"
            : "bg-transparent border-b border-transparent"
        }`}
      >
        <nav
          aria-label="Primary"
          className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8"
        >
          {/* Wordmark */}
          <a
            href="#top"
            onClick={close}
            className="group flex items-baseline gap-2"
            aria-label="New Dimension — back to top"
          >
            <span className="font-display text-[1.35rem] font-medium leading-none tracking-[0.08em]">
              NEW&nbsp;DIMENSION
            </span>
            <span
              className="hidden md:inline-block h-1.5 w-1.5 rounded-full bg-bronze transition-transform duration-500 group-hover:scale-150"
              aria-hidden="true"
            />
          </a>

          {/* Desktop links */}
          <ul className="hidden items-center gap-8 lg:flex">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="link-sweep eyebrow text-ink/80 hover:text-ink"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#enquire"
                className="group inline-flex items-center gap-2 border border-ink/70 px-5 py-2.5 eyebrow transition-colors duration-500 hover:bg-ink hover:text-ivory"
              >
                Start a project
                <ArrowUpRight
                  className="h-3.5 w-3.5 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  aria-hidden="true"
                />
              </a>
            </li>
          </ul>

          {/* Mobile trigger */}
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-2 lg:hidden eyebrow text-ink"
            aria-expanded={open}
            aria-controls="overlay-menu"
          >
            Menu
            <Menu className="h-5 w-5" aria-hidden="true" />
            <span className="sr-only">Open menu</span>
          </button>
        </nav>
      </header>

      {/* Full-screen overlay menu (mobile / tablet) */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="overlay-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            className="fixed inset-0 z-[85] bg-coal text-ivory flex flex-col"
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: "-4%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduce ? { opacity: 0 } : { opacity: 0, y: "-4%" }}
            transition={{ duration: 0.45, ease: EASE }}
          >
            <div className="flex h-16 items-center justify-between px-5 sm:px-8 border-b border-line-dark">
              <span className="font-display text-[1.35rem] font-medium tracking-[0.08em]">
                NEW&nbsp;DIMENSION
              </span>
              <button
                type="button"
                onClick={close}
                className="inline-flex items-center gap-2 eyebrow text-ivory"
              >
                Close
                <X className="h-5 w-5" aria-hidden="true" />
                <span className="sr-only">Close menu</span>
              </button>
            </div>

            <nav aria-label="Mobile" className="flex flex-1 flex-col justify-center px-8">
              <ul className="space-y-2">
                {LINKS.map((l, i) => (
                  <motion.li
                    key={l.href}
                    initial={reduce ? false : { opacity: 0, x: -24 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.12 + i * 0.07, duration: 0.6, ease: EASE }}
                  >
                    <a
                      href={l.href}
                      onClick={close}
                      className="group flex items-baseline gap-4 py-2"
                    >
                      <span className="eyebrow text-bronze-soft">{l.index}</span>
                      <span className="font-display text-5xl sm:text-6xl font-light transition-colors duration-300 group-hover:text-bronze-soft">
                        {l.label}
                      </span>
                    </a>
                  </motion.li>
                ))}
              </ul>
            </nav>

            <motion.div
              initial={reduce ? false : { opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="border-t border-line-dark px-8 py-5 flex flex-wrap items-center justify-between gap-2"
            >
              <p className="eyebrow text-sand">Concept by ARYONIX — demo</p>
              <a
                href="#enquire"
                onClick={close}
                className="eyebrow text-bronze-soft link-sweep"
              >
                Start a project
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
