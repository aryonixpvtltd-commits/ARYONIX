import { ExternalLink } from "lucide-react";
import { BUSINESS } from "@/lib/business";

/**
 * Persistent demo banner — required honest labelling.
 * Fixed height single line, so the fixed nav can safely offset below it.
 */
export function DemoRibbon() {
  return (
    <div className="fixed inset-x-0 top-0 z-[80] h-7 bg-coal text-ivory">
      <div className="mx-auto flex h-full max-w-7xl items-center justify-center gap-x-3 px-4 whitespace-nowrap">
        <p className="flex items-center gap-2 overflow-hidden text-[0.65rem] sm:text-[0.6875rem] uppercase tracking-[0.2em] text-sand">
          <span className="text-bronze-soft font-medium shrink-0">
            ARYONIX concept
          </span>
          <span className="shrink-0" aria-hidden="true">—</span>
          <span className="truncate">
            Design demo, not the live {BUSINESS.name} website
          </span>
        </p>
        <a
          href={BUSINESS.liveSite}
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:inline-flex items-center gap-1 text-[0.6875rem] uppercase tracking-[0.2em] text-bronze-soft link-sweep shrink-0"
        >
          Live site
          <ExternalLink className="h-3 w-3" aria-hidden="true" />
          <span className="sr-only">(opens newdimensionngp.com in a new tab)</span>
        </a>
      </div>
    </div>
  );
}
