"use client";

import { useMemo, useState } from "react";
import {
  ArrowUpRight,
  Check,
  Copy,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Send,
} from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BUSINESS,
  SERVICES,
  mailtoUrl,
  whatsappUrl,
} from "@/lib/business";
import { Reveal } from "./reveal";

type Errors = { name?: string; contact?: string };

export function Enquiry() {
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [service, setService] = useState<string>("Residential design");
  const [location, setLocation] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [handedOff, setHandedOff] = useState<"whatsapp" | "email" | null>(null);

  const composed = useMemo(() => {
    return [
      `Hello ${BUSINESS.name},`,
      ``,
      `I'm ${name.trim() || "…"} and I'd like to discuss a project.`,
      ``,
      `Project type: ${service}`,
      location.trim() ? `Location: ${location.trim()}` : null,
      `Best way to reach me: ${contact.trim() || "…"}`,
      message.trim() ? `` : null,
      message.trim() || null,
      ``,
      `— Sent from the ARYONIX design concept preview`,
    ]
      .filter((l) => l !== null)
      .join("\n");
  }, [name, service, location, contact, message]);

  const validate = (): boolean => {
    const next: Errors = {};
    if (!name.trim()) next.name = "Please tell the studio your name.";
    if (!contact.trim())
      next.contact = "Add a phone number or email so the studio can reply.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const field =
    "h-12 border-line bg-ivory/60 text-[0.95rem] font-light text-ink placeholder:text-taupe/70 focus-visible:ring-bronze/60 focus-visible:border-bronze rounded-none";

  const sendWhatsapp = () => {
    if (!validate()) {
      toast.error("Two small details are missing", {
        description: "Your name and a way to reach you.",
      });
      return;
    }
    window.open(whatsappUrl(composed), "_blank", "noopener,noreferrer");
    setHandedOff("whatsapp");
    toast.success("Opening WhatsApp with your message", {
      description: `Handing off to the studio's verified number ${BUSINESS.phoneDisplay}. Nothing is stored here.`,
    });
  };

  const sendEmail = () => {
    if (!validate()) {
      toast.error("Two small details are missing", {
        description: "Your name and a way to reach you.",
      });
      return;
    }
    window.location.href = mailtoUrl(
      `Project enquiry — ${service}`,
      composed
    );
    setHandedOff("email");
    toast.success("Opening your email app", {
      description: `Addressed to the studio's verified email ${BUSINESS.email}. Nothing is stored here.`,
    });
  };

  const copyMessage = async () => {
    try {
      await navigator.clipboard.writeText(composed);
      toast.success("Message copied", {
        description: "Paste it into WhatsApp, SMS or email — whatever suits you.",
      });
    } catch {
      toast.error("Couldn't access the clipboard", {
        description: `You can still reach the studio directly at ${BUSINESS.phoneDisplay}.`,
      });
    }
  };

  const channels = [
    {
      icon: Phone,
      label: "Call the studio",
      value: BUSINESS.phoneDisplay,
      href: `tel:${BUSINESS.phoneTel}`,
      hint: "Published phone number",
    },
    {
      icon: MessageCircle,
      label: "WhatsApp",
      value: BUSINESS.phoneDisplay,
      href: whatsappUrl(`Hello ${BUSINESS.name}, I'd like to discuss a project.`),
      hint: "Same verified number",
    },
    {
      icon: Mail,
      label: "Email",
      value: BUSINESS.email,
      href: `mailto:${BUSINESS.email}`,
      hint: "Published email address",
    },
    {
      icon: MapPin,
      label: "Studio",
      value: `${BUSINESS.addressLine1}, ${BUSINESS.addressLine2}`,
      href: BUSINESS.mapsUrl,
      hint: "Visits by appointment — call first",
    },
  ];

  return (
    <section
      id="enquire"
      aria-label="Project enquiry"
      className="scroll-mt-24 bg-coal text-ivory"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-24 sm:py-32">
        <div className="grid gap-14 lg:grid-cols-2 lg:gap-20">
          {/* Pitch + channels */}
          <div>
            <Reveal>
              <p className="eyebrow text-bronze-soft">Begin your project</p>
              <h2 className="mt-6 font-display text-[clamp(2.4rem,5vw,4.4rem)] font-light leading-[1.05]">
                Tell the studio
                <br />
                about <em className="italic text-bronze-soft">your space</em>.
              </h2>
              <p className="mt-7 max-w-lg text-sm sm:text-base font-light leading-relaxed text-ivory/75">
                Every enquiry here is handed to the studio&rsquo;s own published
                channels — no forms disappear into a void, and nothing is stored
                by this demo. Choose the way that suits you.
              </p>
            </Reveal>

            <div className="mt-12 grid gap-4 sm:grid-cols-2">
              {channels.map((c, i) => (
                <Reveal key={c.label} delay={0.08 * i}>
                  <a
                    href={c.href}
                    target={c.href.startsWith("http") ? "_blank" : undefined}
                    rel={
                      c.href.startsWith("http")
                        ? "noopener noreferrer"
                        : undefined
                    }
                    className="group flex h-full flex-col border border-line-dark bg-soot/50 p-5 transition-colors duration-500 hover:border-bronze/60"
                  >
                    <span className="flex items-center justify-between">
                      <c.icon className="h-4.5 w-4.5 text-bronze-soft" aria-hidden="true" />
                      <ArrowUpRight
                        className="h-4 w-4 text-sand opacity-0 transition-all duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:opacity-100"
                        aria-hidden="true"
                      />
                    </span>
                    <span className="mt-5 eyebrow text-sand">{c.label}</span>
                    <span className="mt-1.5 break-words text-sm font-light text-ivory/90">
                      {c.value}
                    </span>
                    <span className="mt-2 text-[0.68rem] uppercase tracking-[0.14em] text-taupe">
                      {c.hint}
                    </span>
                  </a>
                </Reveal>
              ))}
            </div>
          </div>

          {/* Form — composes, never fakes a send */}
          <Reveal delay={0.1}>
            <div className="border border-line bg-parchment p-6 text-ink shadow-float sm:p-9">
              <p className="eyebrow text-bronze">Project enquiry</p>
              <h3 className="mt-4 font-display text-3xl font-light">
                Compose your message
              </h3>

              <form
                className="mt-8 space-y-5"
                onSubmit={(e) => {
                  e.preventDefault();
                  sendWhatsapp();
                }}
                noValidate
              >
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="enq-name" className="eyebrow text-taupe">
                      Your name *
                    </Label>
                    <Input
                      id="enq-name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Full name"
                      autoComplete="name"
                      aria-invalid={!!errors.name}
                      className={field}
                    />
                    {errors.name && (
                      <p role="alert" className="text-xs text-destructive">
                        {errors.name}
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="enq-contact" className="eyebrow text-taupe">
                      Phone or email *
                    </Label>
                    <Input
                      id="enq-contact"
                      value={contact}
                      onChange={(e) => setContact(e.target.value)}
                      placeholder="+91 · or you@email.com"
                      autoComplete="tel email"
                      aria-invalid={!!errors.contact}
                      className={field}
                    />
                    {errors.contact && (
                      <p role="alert" className="text-xs text-destructive">
                        {errors.contact}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="enq-service" className="eyebrow text-taupe">
                      Project type
                    </Label>
                    <Select value={service} onValueChange={setService}>
                      <SelectTrigger
                        id="enq-service"
                        className={`${field} w-full [&>span]:font-light`}
                      >
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent className="max-h-72 rounded-none border-line bg-parchment scroll-slim">
                        {SERVICES.map((s) => (
                          <SelectItem
                            key={s.name}
                            value={s.name}
                            className="rounded-none font-light focus:bg-linen"
                          >
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="enq-location" className="eyebrow text-taupe">
                      Location{" "}
                      <span className="normal-case tracking-normal text-taupe/70">
                        (optional)
                      </span>
                    </Label>
                    <Input
                      id="enq-location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="City / locality"
                      className={field}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="enq-message" className="eyebrow text-taupe">
                    About the space{" "}
                    <span className="normal-case tracking-normal text-taupe/70">
                      (optional)
                    </span>
                  </Label>
                  <Textarea
                    id="enq-message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={4}
                    placeholder="A few lines — rooms, rough timeline, anything on your mind."
                    className="min-h-28 border-line bg-ivory/60 text-[0.95rem] font-light placeholder:text-taupe/70 focus-visible:ring-bronze/60 focus-visible:border-bronze rounded-none resize-none"
                  />
                </div>

                {/* Live preview — full transparency of what will be sent */}
                <div className="border border-line bg-ivory/70 p-4">
                  <p className="eyebrow text-taupe">
                    What the studio will receive
                  </p>
                  <pre className="mt-3 whitespace-pre-wrap break-words font-sans text-[0.8rem] font-light leading-relaxed text-ink/80">
                    {composed}
                  </pre>
                </div>

                <div className="flex flex-col gap-3 pt-1 sm:flex-row">
                  <button
                    type="submit"
                    className="group inline-flex flex-1 items-center justify-center gap-2.5 bg-ink px-6 py-4 eyebrow text-ivory transition-colors duration-500 hover:bg-bronze"
                  >
                    <Send className="h-4 w-4" aria-hidden="true" />
                    Send via WhatsApp
                  </button>
                  <button
                    type="button"
                    onClick={sendEmail}
                    className="inline-flex flex-1 items-center justify-center gap-2.5 border border-ink/60 px-6 py-4 eyebrow text-ink transition-colors duration-500 hover:bg-ink hover:text-ivory"
                  >
                    <Mail className="h-4 w-4" aria-hidden="true" />
                    Send via Email
                  </button>
                  <button
                    type="button"
                    onClick={copyMessage}
                    aria-label="Copy the composed message to the clipboard"
                    className="inline-flex items-center justify-center gap-2 border border-line px-4 py-4 eyebrow text-taupe transition-colors duration-500 hover:border-bronze hover:text-bronze sm:px-5"
                  >
                    <Copy className="h-4 w-4" aria-hidden="true" />
                    Copy
                  </button>
                </div>

                <p className="text-[0.7rem] leading-relaxed text-taupe">
                  Buttons open WhatsApp / your email app with this message
                  addressed to the studio&rsquo;s verified contact details. This
                  concept does not submit, store or forward anything itself.
                </p>

                {handedOff && (
                  <div
                    role="status"
                    className="flex items-start gap-3 border border-bronze/50 bg-bronze/10 p-4 text-sm font-light text-ink/85"
                  >
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-bronze" aria-hidden="true" />
                    <p>
                      {handedOff === "whatsapp"
                        ? "WhatsApp should now be open with your message. If it didn't open, call "
                        : "Your email app should now be open with the draft. If it didn't, email "}
                      <a
                        className="link-sweep font-medium text-ink"
                        href={
                          handedOff === "whatsapp"
                            ? `tel:${BUSINESS.phoneTel}`
                            : `mailto:${BUSINESS.email}`
                        }
                      >
                        {handedOff === "whatsapp"
                          ? BUSINESS.phoneDisplay
                          : BUSINESS.email}
                      </a>
                      {handedOff === "whatsapp" ? " directly." : " directly."}
                    </p>
                  </div>
                )}
              </form>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
