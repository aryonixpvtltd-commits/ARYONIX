import { ExternalLink, Mail, Phone } from "lucide-react";
import { BUSINESS, CREDIT } from "@/lib/business";
import { Reveal } from "./reveal";

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-ink text-ivory" aria-label="Footer">
      {/* Big closing wordmark */}
      <div className="border-b border-line-dark">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-16 sm:py-24">
          <Reveal>
            <p className="font-display font-light leading-none tracking-[0.06em] text-[clamp(2.6rem,9vw,7.5rem)] text-ivory/95">
              NEW DIMENSION
            </p>
            <p className="mt-4 eyebrow text-bronze-soft">
              Interior design · Nagpur · Since {BUSINESS.establishedYear}
            </p>
          </Reveal>
        </div>
      </div>

      {/* Columns */}
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14 grid gap-12 md:grid-cols-3">
        <div>
          <p className="eyebrow text-sand">Contact — as published by the firm</p>
          <ul className="mt-5 space-y-3 text-sm font-light text-ivory/85">
            <li>
              <a
                href={`tel:${BUSINESS.phoneTel}`}
                className="link-sweep inline-flex items-center gap-2.5"
              >
                <Phone className="h-3.5 w-3.5 text-bronze-soft" aria-hidden="true" />
                {BUSINESS.phoneDisplay}
              </a>
            </li>
            <li>
              <a
                href={`mailto:${BUSINESS.email}`}
                className="link-sweep inline-flex items-center gap-2.5 break-all"
              >
                <Mail className="h-3.5 w-3.5 shrink-0 text-bronze-soft" aria-hidden="true" />
                {BUSINESS.email}
              </a>
            </li>
            <li className="text-ivory/75">
              {BUSINESS.addressLine1}, {BUSINESS.addressLine2}
            </li>
            <li className="text-ivory/60">
              Regions: {BUSINESS.regions.join(" · ")}
            </li>
          </ul>
        </div>

        <div>
          <p className="eyebrow text-sand">Navigate</p>
          <ul className="mt-5 space-y-3 text-sm font-light text-ivory/85">
            {[
              ["#practice", "The practice"],
              ["#services", "Services"],
              ["#work", "Gallery"],
              ["#studio", "Partners"],
              ["#enquire", "Project enquiry"],
            ].map(([href, label]) => (
              <li key={href}>
                <a href={href} className="link-sweep">
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="eyebrow text-sand">About this page</p>
          <p className="mt-5 text-[0.8rem] font-light leading-relaxed text-ivory/70">
            {CREDIT.conceptLine}
          </p>
          <a
            href={BUSINESS.liveSite}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex items-center gap-2 eyebrow text-bronze-soft link-sweep"
          >
            The firm&rsquo;s live website
            <ExternalLink className="h-3 w-3" aria-hidden="true" />
          </a>
          <p className="mt-4 text-[0.7rem] leading-relaxed text-taupe">
            {CREDIT.photography}
          </p>
        </div>
      </div>

      {/* Legal / demo bar */}
      <div className="border-t border-line-dark">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-7 flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <p className="max-w-3xl text-[0.68rem] leading-relaxed text-sand">
            {CREDIT.disclaimer}
          </p>
          <p className="shrink-0 text-[0.68rem] uppercase tracking-[0.2em] text-taupe">
            © {year} {BUSINESS.name} · Concept by {CREDIT.concept}
          </p>
        </div>
      </div>
    </footer>
  );
}
