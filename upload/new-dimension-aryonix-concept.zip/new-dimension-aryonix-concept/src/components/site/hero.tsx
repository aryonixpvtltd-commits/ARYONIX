"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { EASE } from "./reveal";

const LINES = ["Interiors rooted", "in vastu, drawn with", "an artist's hand."];

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "38%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section
      ref={ref}
      id="top"
      aria-label="Introduction"
      className="relative h-[100svh] min-h-[620px] overflow-hidden bg-coal text-ivory"
    >
      {/* Backdrop photograph with slow cinematic settle */}
      <motion.div
        className="absolute inset-0"
        style={reduce ? undefined : { y: imgY }}
      >
        <div className={reduce ? "absolute inset-0" : "absolute inset-0 animate-kenburns"}>
          <Image
            src="/images/hero.jpg"
            alt="Placeholder hero visual — a warm, sunlit ivory living room with timber furniture. Licensed stock imagery, not a New Dimension project."
            fill
            priority
            sizes="100vw"
            className="object-cover object-center"
          />
        </div>
        {/* Cinematic scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-coal/90 via-coal/35 to-coal/55" />
        <div className="absolute inset-0 bg-gradient-to-r from-coal/55 via-transparent to-transparent" />
      </motion.div>

      {/* Content */}
      <motion.div
        className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-end px-5 pb-24 sm:px-8 sm:pb-28"
        style={reduce ? undefined : { y: contentY, opacity: contentOpacity }}
      >
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.25, ease: EASE }}
          className="eyebrow text-bronze-soft"
        >
          New Dimension · Interior design studio · Nagpur
        </motion.p>

        <h1 className="mt-6 font-display font-light leading-[1.04] text-[clamp(2.6rem,7.2vw,5.9rem)]">
          {LINES.map((line, i) => (
            <span key={line} className="block overflow-hidden">
              <motion.span
                className="block"
                initial={reduce ? false : { y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 1.1, delay: 0.38 + i * 0.14, ease: EASE }}
              >
                {i === LINES.length - 1 ? (
                  <>
                    an <em className="italic font-normal text-bronze-soft">artist&rsquo;s</em> hand.
                  </>
                ) : (
                  line
                )}
              </motion.span>
            </span>
          ))}
        </h1>

        <motion.p
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.95, ease: EASE }}
          className="mt-7 max-w-xl text-[0.95rem] sm:text-base font-light leading-relaxed text-ivory/80"
        >
          A partner-led practice designing homes, workplaces, hospitality and
          retail across Maharashtra, Madhya Pradesh and Chhattisgarh — since
          2007.
        </motion.p>

        <motion.div
          initial={reduce ? false : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.1, ease: EASE }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <a
            href="#enquire"
            className="group inline-flex items-center gap-2.5 bg-ivory px-7 py-3.5 eyebrow text-ink transition-colors duration-500 hover:bg-bronze hover:text-parchment"
          >
            Begin a project
            <ArrowUpRight
              className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              aria-hidden="true"
            />
          </a>
          <a
            href="#work"
            className="group inline-flex items-center gap-2.5 border border-ivory/40 px-7 py-3.5 eyebrow text-ivory transition-colors duration-500 hover:border-ivory hover:bg-ivory/10"
          >
            View the gallery
            <ArrowDown
              className="h-4 w-4 transition-transform duration-500 group-hover:translate-y-0.5"
              aria-hidden="true"
            />
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 1 }}
        className="absolute bottom-6 right-5 sm:right-8 z-10 hidden sm:flex items-center gap-3"
        aria-hidden="true"
      >
        <span className="eyebrow text-ivory/50">Scroll</span>
        <span className="animate-scroll-cue text-ivory/70">
          <ArrowDown className="h-4 w-4" />
        </span>
      </motion.div>

      {/* Honest imagery caption */}
      <p className="absolute bottom-2 left-5 sm:left-8 z-10 text-[0.6rem] uppercase tracking-[0.18em] text-ivory/40">
        Placeholder imagery · Unsplash
      </p>
    </section>
  );
}
