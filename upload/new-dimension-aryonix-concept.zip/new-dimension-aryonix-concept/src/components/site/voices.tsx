import { Quote } from "lucide-react";
import { TESTIMONIALS, TESTIMONIALS_NOTE } from "@/lib/business";
import { Reveal } from "./reveal";

export function Voices() {
  return (
    <section
      aria-label="What clients have said"
      className="bg-parchment border-b border-line"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-24 sm:py-32">
        <Reveal>
          <p className="eyebrow text-bronze">In clients&rsquo; words</p>
        </Reveal>

        <div className="mt-12 grid gap-14 md:grid-cols-2 md:gap-10">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.author} delay={i * 0.14}>
              <figure
                className={`relative flex h-full flex-col justify-between border-line pt-10 ${
                  i === 1 ? "md:border-l md:pl-10" : "md:pr-10"
                }`}
              >
                <span
                  aria-hidden="true"
                  className="absolute left-0 top-0 font-display text-[5rem] leading-none text-bronze/25 md:-left-2"
                >
                  <Quote className="h-8 w-8 -scale-x-100 text-bronze/50" />
                </span>
                <blockquote className="font-display text-[1.7rem] sm:text-[2rem] font-light italic leading-[1.35] text-ink/90">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>
                <figcaption className="mt-8">
                  <span className="block text-sm font-medium tracking-wide text-ink">
                    {t.author}
                  </span>
                  <span className="mt-1 block text-xs text-taupe">
                    Client of the firm
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-14 border-t border-line pt-6 text-xs leading-relaxed text-taupe">
            {TESTIMONIALS_NOTE}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
