"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { FACTS, POSITIONING, SERVICES } from "@/lib/business";
import { EASE, Reveal } from "./reveal";

const MARQUEE_WORDS = SERVICES.map((s) => s.name);

function MarqueeRow({ ariaHidden = false }: { ariaHidden?: boolean }) {
  return (
    <div
      aria-hidden={ariaHidden || undefined}
      className="flex shrink-0 items-center gap-10 pr-10"
    >
      {MARQUEE_WORDS.map((w, i) => (
        <span key={`${w}-${i}`} className="flex items-center gap-10">
          <span className="font-display text-2xl sm:text-3xl font-light italic text-ivory/75 whitespace-nowrap">
            {w}
          </span>
          <span className="h-1.5 w-1.5 rotate-45 bg-bronze/70" aria-hidden="true" />
        </span>
      ))}
    </div>
  );
}

export function Practice() {
  const imgRef = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: imgRef,
    offset: ["start end", "end start"],
  });
  const parallaxY = useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]);

  return (
    <section id="practice" aria-label="The practice" className="scroll-mt-24">
      {/* Service-word marquee bridging hero and statement */}
      <div className="overflow-hidden border-b border-line-dark bg-coal py-6">
        <div className="flex w-max animate-marquee">
          <MarqueeRow />
          <MarqueeRow ariaHidden />
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-5 sm:px-8 pt-24 sm:pt-36 pb-20 sm:pb-28">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-10">
          {/* Statement */}
          <div className="lg:col-span-7">
            <Reveal>
              <p className="eyebrow text-bronze">{POSITIONING.eyebrow}</p>
            </Reveal>

            <h2 className="mt-8 font-display font-light leading-[1.06] text-[clamp(2.4rem,5.4vw,4.6rem)]">
              {[...POSITIONING.statement].map((line, i) => (
                <span key={line} className="block overflow-hidden">
                  <motion.span
                    className="block"
                    initial={reduce ? false : { y: "108%" }}
                    whileInView={{ y: 0 }}
                    viewport={{ once: true, margin: "-60px 0px" }}
                    transition={{ duration: 1, delay: i * 0.14, ease: EASE }}
                  >
                    {i === 0 ? (
                      <>
                        Edgy, yet <em className="italic text-bronze">attainable</em>.
                      </>
                    ) : (
                      <>
                        Current, yet <em className="italic text-bronze">timeless</em>.
                      </>
                    )}
                  </motion.span>
                </span>
              ))}
            </h2>

            <Reveal delay={0.2} className="mt-10 max-w-xl">
              <p className="text-base sm:text-lg font-light leading-relaxed text-ink/85">
                {POSITIONING.body}
              </p>
              <p className="mt-4 text-xs text-taupe">{POSITIONING.bodyNote}</p>
            </Reveal>
          </div>

          {/* Parallax photograph */}
          <div className="lg:col-span-5">
            <Reveal delay={0.15}>
              <div
                ref={imgRef}
                className="relative ml-auto aspect-[4/5] w-full max-w-md overflow-hidden shadow-card lg:translate-y-10"
              >
                <motion.div
                  className="absolute inset-[-10%]"
                  style={reduce ? undefined : { y: parallaxY }}
                >
                  <Image
                    src="/images/corner-lamp.jpg"
                    alt="Placeholder visual — an ivory living room styled with layered textiles and art. Licensed stock imagery."
                    fill
                    sizes="(min-width: 1024px) 33vw, 90vw"
                    className="object-cover"
                  />
                </motion.div>
                <p className="absolute bottom-3 left-4 text-[0.6rem] uppercase tracking-[0.18em] text-parchment/80">
                  Placeholder imagery · Unsplash
                </p>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Verified facts row */}
        <dl className="mt-20 sm:mt-32 grid grid-cols-2 gap-y-10 border-t border-line pt-10 lg:grid-cols-4">
          {FACTS.map((f, i) => (
            <Reveal key={f.value} delay={i * 0.08}>
              <div className="px-0 sm:px-6 first:pl-0 border-l-0 lg:border-l lg:first:border-l-0 border-line">
                <dt className="sr-only">{f.label}</dt>
                <dd>
                  <span className="font-display text-5xl sm:text-6xl font-light text-ink">
                    {f.value}
                  </span>
                  <span className="mt-3 block text-sm font-medium text-ink/80">
                    {f.label}
                  </span>
                  <span className="mt-1 block text-xs leading-relaxed text-taupe">
                    {f.note}
                  </span>
                </dd>
              </div>
            </Reveal>
          ))}
        </dl>

        <Reveal delay={0.1}>
          <p className="mt-8 max-w-md text-xs leading-relaxed text-taupe">
            Facts above are drawn from the firm&rsquo;s own published website and
            partner bio sheets, verified at the time this concept was built.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
