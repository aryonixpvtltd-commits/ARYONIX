"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, ChevronLeft, ChevronRight, ImageOff } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  GALLERY,
  GALLERY_FILTERS,
  GALLERY_NOTE,
  type GalleryItem,
} from "@/lib/business";
import { EASE, Reveal } from "./reveal";

/** Asymmetrical editorial rhythm — cycles across the grid. */
const RHYTHM = [
  "sm:col-span-7 aspect-[4/3]",
  "sm:col-span-5 aspect-[3/4] sm:mt-20",
  "sm:col-span-5 aspect-[3/4]",
  "sm:col-span-7 aspect-[16/11] sm:-mt-14",
  "sm:col-span-6 aspect-[4/3]",
  "sm:col-span-6 aspect-[4/3] sm:mt-16",
];

export function Portfolio() {
  const [filter, setFilter] = useState<(typeof GALLERY_FILTERS)[number]>("All");
  const [lightbox, setLightbox] = useState<number | null>(null);
  const reduce = useReducedMotion();

  const items = useMemo(
    () => (filter === "All" ? GALLERY : GALLERY.filter((g) => g.category === filter)),
    [filter]
  );

  const current: GalleryItem | null = lightbox === null ? null : items[lightbox];

  const step = (dir: 1 | -1) => {
    if (lightbox === null) return;
    setLightbox((lightbox + dir + items.length) % items.length);
  };

  return (
    <section id="work" aria-label="Gallery" className="scroll-mt-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-24 sm:py-32">
        {/* Head */}
        <div className="flex flex-col gap-10 lg:flex-row lg:items-end lg:justify-between">
          <Reveal>
            <p className="eyebrow text-bronze">Gallery — a direction</p>
            <h2 className="mt-6 font-display text-[clamp(2.4rem,5vw,4.4rem)] font-light leading-[1.05]">
              Layout studies in
              <br />
              light <em className="italic text-bronze">&amp;</em> material.
            </h2>
          </Reveal>
          <Reveal delay={0.12} className="max-w-md">
            <div className="flex gap-3 border border-line bg-parchment p-4">
              <ImageOff className="mt-0.5 h-4 w-4 shrink-0 text-bronze" aria-hidden="true" />
              <p className="text-xs leading-relaxed text-ink/70">{GALLERY_NOTE}</p>
            </div>
          </Reveal>
        </div>

        {/* Filters */}
        <Reveal delay={0.05}>
          <div
            role="tablist"
            aria-label="Filter gallery by space type"
            className="mt-14 flex flex-wrap items-center gap-x-8 gap-y-3 border-y border-line py-4"
          >
            {GALLERY_FILTERS.map((f) => {
              const count =
                f === "All" ? GALLERY.length : GALLERY.filter((g) => g.category === f).length;
              const active = filter === f;
              return (
                <button
                  key={f}
                  role="tab"
                  aria-selected={active}
                  type="button"
                  onClick={() => {
                    setFilter(f);
                    setLightbox(null);
                  }}
                  className={`group relative eyebrow pb-1 transition-colors duration-300 ${
                    active ? "text-ink" : "text-taupe hover:text-ink"
                  }`}
                >
                  {f}
                  <span className="ml-1.5 text-[0.5625rem] text-bronze">{count}</span>
                  <span
                    aria-hidden="true"
                    className={`absolute inset-x-0 -bottom-px h-px bg-bronze transition-transform duration-500 ${
                      active ? "scale-x-100" : "scale-x-0 group-hover:scale-x-50"
                    }`}
                  />
                </button>
              );
            })}
          </div>
        </Reveal>

        {/* Asymmetric grid */}
        <motion.div
          layout
          className="mt-12 grid grid-cols-1 sm:grid-cols-12 gap-x-6 gap-y-12 sm:gap-y-8"
        >
          <AnimatePresence mode="popLayout">
            {items.map((item, i) => (
              <motion.figure
                layout
                key={item.src}
                initial={reduce ? { opacity: 0 } : { opacity: 0, y: 40, scale: 0.985 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={reduce ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.985 }}
                transition={{ duration: 0.7, ease: EASE }}
                className={`group relative ${RHYTHM[i % RHYTHM.length]}`}
              >
                <button
                  type="button"
                  onClick={() => setLightbox(i)}
                  className="absolute inset-0 z-10"
                  aria-label={`Open larger view: ${item.title} (placeholder image)`}
                />
                <div className="relative h-full w-full overflow-hidden bg-linen shadow-card">
                  <Image
                    src={item.src}
                    alt={item.alt}
                    fill
                    sizes="(min-width: 640px) 58vw, 100vw"
                    className="object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
                  />
                  {/* caption veil */}
                  <div className="absolute inset-0 bg-gradient-to-t from-coal/85 via-transparent to-transparent opacity-90 transition-opacity duration-700 group-hover:opacity-100" />
                  <span className="absolute left-4 top-4 border border-parchment/30 bg-coal/40 px-2.5 py-1 text-[0.58rem] uppercase tracking-[0.2em] text-parchment/90 backdrop-blur-sm">
                    Placeholder
                  </span>
                  <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5">
                    <div>
                      <p className="font-display text-2xl font-light text-parchment">
                        {item.title}
                      </p>
                      <p className="mt-1 text-[0.65rem] uppercase tracking-[0.22em] text-parchment/70">
                        Speaks to · {item.serviceHint}
                      </p>
                    </div>
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-parchment/40 text-parchment transition-all duration-500 group-hover:bg-parchment group-hover:text-ink">
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </span>
                  </figcaption>
                </div>
              </motion.figure>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Lightbox */}
      <Dialog open={current !== null} onOpenChange={(o) => !o && setLightbox(null)}>
        {current && (
          <DialogContent
            className="max-w-5xl sm:max-w-5xl border-line-dark bg-coal p-0 gap-0 text-ivory sm:rounded-none [&>button]:text-ivory [&>button]:bg-coal/60 [&>button]:rounded-full [&>button]:p-1.5"
            aria-describedby="lightbox-note"
          >
            <DialogHeader className="sr-only">
              <DialogTitle>
                {current.title} — placeholder visual
              </DialogTitle>
              <DialogDescription id="lightbox-note">
                Licensed placeholder photography, not a New Dimension project.
              </DialogDescription>
            </DialogHeader>
            <div className="relative aspect-[16/10] w-full overflow-hidden bg-soot">
              <AnimatePresence mode="wait">
                <motion.div
                  key={current.src}
                  initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 1.02 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.99 }}
                  transition={{ duration: 0.45, ease: EASE }}
                  className="absolute inset-0"
                >
                  <Image
                    src={current.src}
                    alt={current.alt}
                    fill
                    sizes="(min-width: 1024px) 960px, 100vw"
                    className="object-cover"
                    priority
                  />
                </motion.div>
              </AnimatePresence>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-7">
              <div>
                <p className="font-display text-2xl font-light">{current.title}</p>
                <p className="mt-0.5 text-[0.65rem] uppercase tracking-[0.22em] text-sand">
                  Placeholder · Unsplash — speaks to {current.serviceHint}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => step(-1)}
                  className="grid h-10 w-10 place-items-center rounded-full border border-line-dark text-ivory transition-colors hover:border-bronze hover:text-bronze-soft"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="h-4 w-4" aria-hidden="true" />
                </button>
                <span className="eyebrow w-14 text-center text-sand" aria-live="polite">
                  {lightbox === null ? "" : `${lightbox + 1} / ${items.length}`}
                </span>
                <button
                  type="button"
                  onClick={() => step(1)}
                  className="grid h-10 w-10 place-items-center rounded-full border border-line-dark text-ivory transition-colors hover:border-bronze hover:text-bronze-soft"
                  aria-label="Next image"
                >
                  <ChevronRight className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </section>
  );
}
