import { MapPin } from "lucide-react";
import { BUSINESS, PARTNERS, PARTNERS_NOTE } from "@/lib/business";
import { Reveal } from "./reveal";

export function Studio() {
  return (
    <section
      id="studio"
      aria-label="The studio and its partners"
      className="scroll-mt-24 bg-coal text-ivory"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-24 sm:py-32">
        <div className="grid gap-16 lg:grid-cols-12">
          {/* Head + address */}
          <div className="lg:col-span-4">
            <Reveal>
              <p className="eyebrow text-bronze-soft">The partners</p>
              <h2 className="mt-6 font-display text-[clamp(2.2rem,4.4vw,3.6rem)] font-light leading-[1.08]">
                Two hands,
                <br />
                <em className="italic text-bronze-soft">one practice</em>.
              </h2>
              <p className="mt-6 max-w-sm text-sm sm:text-[0.95rem] font-light leading-relaxed text-ivory/70">
                New Dimension is owned and led by two partners, working hand in
                hand — one root in vastu, one in art — from a single studio in
                Nagpur.
              </p>
            </Reveal>

            <Reveal delay={0.15}>
              <address className="mt-10 not-italic">
                <p className="eyebrow text-sand">Studio</p>
                <p className="mt-3 flex items-start gap-2 text-sm font-light leading-relaxed text-ivory/80">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-bronze-soft" aria-hidden="true" />
                  <span>
                    {BUSINESS.addressLine1}
                    <br />
                    {BUSINESS.addressLine2}
                  </span>
                </p>
                <a
                  href={BUSINESS.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-sweep mt-3 ml-6 inline-block eyebrow text-bronze-soft"
                >
                  View map
                </a>
                <p className="mt-6 eyebrow text-sand">Regions served</p>
                <p className="mt-3 text-sm font-light text-ivory/80">
                  {BUSINESS.regions.join(" · ")}
                </p>
              </address>
            </Reveal>
          </div>

          {/* Partner cards */}
          <div className="lg:col-span-8 grid gap-8 md:grid-cols-2">
            {PARTNERS.map((p, i) => (
              <Reveal key={p.name} delay={0.1 + i * 0.12}>
                <article className="group flex h-full flex-col border border-line-dark bg-soot/60 p-7 sm:p-9 transition-colors duration-700 hover:border-bronze/50">
                  {/* Monogram */}
                  <div className="flex items-center justify-between">
                    <span
                      aria-hidden="true"
                      className="grid h-16 w-16 place-items-center rounded-full border border-bronze/60 font-display text-2xl font-light tracking-[0.14em] text-bronze-soft transition-colors duration-700 group-hover:bg-bronze group-hover:text-coal"
                    >
                      {p.initials}
                    </span>
                    <span className="eyebrow text-sand">{String(i + 1).padStart(2, "0")}</span>
                  </div>

                  <h3 className="mt-7 font-display text-3xl font-light">{p.name}</h3>
                  <p className="mt-1 eyebrow text-bronze-soft">{p.role}</p>

                  <ul className="mt-7 space-y-3.5 border-t border-line-dark pt-7">
                    {p.credentials.map((c) => (
                      <li
                        key={c}
                        className="flex gap-3 text-[0.83rem] font-light leading-relaxed text-ivory/75"
                      >
                        <span
                          aria-hidden="true"
                          className="mt-[0.55rem] h-1 w-1 shrink-0 rotate-45 bg-bronze"
                        />
                        {c}
                      </li>
                    ))}
                  </ul>
                </article>
              </Reveal>
            ))}

            <Reveal delay={0.2} className="md:col-span-2">
              <p className="text-xs leading-relaxed text-sand">{PARTNERS_NOTE}</p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
