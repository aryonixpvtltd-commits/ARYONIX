"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, Plus } from "lucide-react";
import { SERVICES } from "@/lib/business";
import { EASE, Reveal } from "./reveal";

export function Services() {
  // Services with published descriptions open the accordion; index within detailed subset
  const detailed = SERVICES.filter((s) => s.hasDetail);
  const [open, setOpen] = useState<number | null>(0);
  const reduce = useReducedMotion();

  return (
    <section
      id="services"
      aria-label="Services"
      className="scroll-mt-24 bg-parchment border-y border-line"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-24 sm:py-32">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* Section head */}
          <div className="lg:col-span-4">
            <Reveal>
              <p className="eyebrow text-bronze">What the studio does</p>
              <h2 className="mt-6 font-display text-[clamp(2.2rem,4.4vw,3.6rem)] font-light leading-[1.08]">
                Fourteen ways
                <br />
                of shaping
                <em className="italic text-bronze"> space</em>.
              </h2>
              <p className="mt-6 max-w-sm text-sm sm:text-[0.95rem] font-light leading-relaxed text-ink/75">
                The studio&rsquo;s published service list, in its own order. Six
                lines carry descriptions on the firm&rsquo;s website — shown here
                as published; the rest are listed as the firm lists them.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <a
                href="#enquire"
                className="group mt-8 inline-flex items-center gap-2 eyebrow text-ink link-sweep"
              >
                Discuss your project
                <ArrowUpRight
                  className="h-3.5 w-3.5 text-bronze transition-transform duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  aria-hidden="true"
                />
              </a>
            </Reveal>
          </div>

          {/* Accordion of described services */}
          <div className="lg:col-span-8">
            <ul className="border-t border-line">
              {detailed.map((s, i) => {
                const isOpen = open === i;
                return (
                  <Reveal as="li" key={s.name} delay={i * 0.05} className="border-b border-line">
                    <h3>
                      <button
                        type="button"
                        onClick={() => setOpen(isOpen ? null : i)}
                        aria-expanded={isOpen}
                        aria-controls={`service-panel-${i}`}
                        id={`service-trigger-${i}`}
                        className="group flex w-full items-center gap-5 sm:gap-8 py-6 sm:py-7 text-left"
                      >
                        <span className="eyebrow w-8 shrink-0 text-bronze" aria-hidden="true">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <span
                          className={`flex-1 font-display text-2xl sm:text-[2rem] font-light leading-tight transition-colors duration-300 ${
                            isOpen ? "text-ink" : "text-ink/70 group-hover:text-ink"
                          }`}
                        >
                          {s.name}
                        </span>
                        <span
                          className={`grid h-9 w-9 shrink-0 place-items-center rounded-full border transition-all duration-500 ${
                            isOpen
                              ? "border-bronze bg-bronze text-parchment rotate-45"
                              : "border-line text-ink/60 group-hover:border-bronze group-hover:text-bronze"
                          }`}
                        >
                          <Plus className="h-4 w-4" aria-hidden="true" />
                        </span>
                      </button>
                    </h3>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          id={`service-panel-${i}`}
                          role="region"
                          aria-labelledby={`service-trigger-${i}`}
                          initial={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
                          animate={reduce ? { opacity: 1 } : { height: "auto", opacity: 1 }}
                          exit={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
                          transition={{ duration: 0.55, ease: EASE }}
                          className="overflow-hidden"
                        >
                          <p className="max-w-2xl pb-7 pl-13 sm:pl-16 pr-4 text-sm sm:text-[0.95rem] font-light leading-relaxed text-ink/75">
                            {s.description}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </Reveal>
                );
              })}
            </ul>

            {/* Remaining published services */}
            <Reveal delay={0.1}>
              <p className="mt-12 eyebrow text-taupe">
                Also listed by the firm
              </p>
              <ul className="mt-5 flex flex-wrap gap-x-3 gap-y-3" aria-label="Additional services listed by the firm">
                {SERVICES.filter((s) => !s.hasDetail).map((s) => (
                  <li
                    key={s.name}
                    className="border border-line bg-ivory px-4 py-2 text-[0.8rem] font-light tracking-wide text-ink/75"
                  >
                    {s.name}
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-xs leading-relaxed text-taupe">
                Service list and descriptions adapted from newdimensionngp.com,
                verified when this concept was built.
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
